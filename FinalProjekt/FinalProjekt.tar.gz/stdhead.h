#ifndef STDHEAD_H_INCLUDED
#define STDHEAD_H_INCLUDED

#include <stdlib.h>
#include <stdio.h>
#include <iostream>
#include <math.h>

#include <cv.h>
#include <cxcore.h>
#include <highgui.h>
#include <highgui.h>
#include <string>

#endif // STDHEAD_H_INCLUDED
